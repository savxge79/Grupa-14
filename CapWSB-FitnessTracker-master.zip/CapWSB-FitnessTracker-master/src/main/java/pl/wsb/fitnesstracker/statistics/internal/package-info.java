@NonNullByDefault
package pl.wsb.fitnesstracker.statistics.internal;

import org.eclipse.jdt.annotation.NonNullByDefault;