package pl.wsb.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.wsb.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
